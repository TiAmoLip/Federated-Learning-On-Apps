package com.example.serverapp

import android.content.ContentProvider
import android.content.ContentResolver
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.util.Log
import com.google.gson.Gson
import java.io.File
class AggregateGradProvider : ContentProvider() {

    private val gradientReq = 1
    private val authority = "com.example.serverapp.provider"
    private var dbHelper:GradientDatabase?=null
    private val uriMatcher by lazy {
        UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(authority,"CKPT",gradientReq)
        }
    }

    override fun onCreate() = context?.let{
        dbHelper = GradientDatabase(it,"modelckpt.db",GlobalApplication.DatabaseVersion)
        true
    }?:false


    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ) = dbHelper?.let {
        val db = it.readableDatabase
        when(uriMatcher.match(uri)) {
            gradientReq -> {
//                Log.d("Server","Received query request")
                db.query("CKPT", projection, selection, selectionArgs, null, null, sortOrder)
            }
            else -> null
        }
    }

    override fun getType(uri: Uri): String? {
        TODO("Not allowed")
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        TODO("Not allowed")
    }

    override fun delete(p0: Uri, p1: String?, p2: Array<out String>?): Int {
        TODO("Not allowed")
    }

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<String>?
    ) = dbHelper?.let {
        val db = it.readableDatabase
        val updateRows = when(uriMatcher.match(uri)) {
            gradientReq -> {
//                Log.d("Server","Received update request")
                db.update("CKPT", values, selection, selectionArgs)
            }
            else -> 0
        }
        updateRows
    }?:0


}

