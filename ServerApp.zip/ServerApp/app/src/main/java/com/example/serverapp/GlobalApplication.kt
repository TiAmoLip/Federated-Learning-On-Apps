package com.example.serverapp

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.io.File

class GlobalApplication: Application() {
    companion object {
        @Suppress("StaticFieldLeak")
        lateinit var context: Context
        var currentParticipants = mutableListOf<String>()

        var DatabaseVersion = 10
    }

    override fun onCreate() {
        super.onCreate()
        context = applicationContext

    }

}