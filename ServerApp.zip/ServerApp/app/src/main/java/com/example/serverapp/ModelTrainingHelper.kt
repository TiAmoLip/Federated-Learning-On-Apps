package com.example.serverapp


import android.content.Context
import android.content.Intent
import android.util.Log

import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.lang.RuntimeException
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.FloatBuffer

class ModelTrainingHelper(val context: Context) {

    private val ckptPath = "${context.filesDir.path}/CKPT/model.ckpt"

    private val trainingSamples: MutableList<TrainingSample> = mutableListOf()
    private var interpreter: Interpreter?=null
    var ModelLoaded = false
    private val DEBUGKEY = "dense_0/bias:0"

    data class TrainingSample(val bottleneck: FloatArray, val label: FloatArray)

    init {
        setupModel()
    }

    private fun setupModel():Boolean {
        val options = Interpreter.Options()
        return try {
            val modelFile = FileUtil.loadMappedFile(GlobalApplication.context,"model.tflite")
            interpreter = Interpreter(modelFile, options)

            val modelPathInput = HashMap<String,Any> ()
            modelPathInput["checkpoint_path"] = ckptPath
            val output = HashMap<String,Any>()
            val bias = FloatBuffer.allocate(10)
            output[DEBUGKEY] = bias
            interpreter?.runSignature(modelPathInput,output,"restore")
            interpreter?.let {
                Log.d("Server", "model setup success")
                debugInfo(bias)
            }
            ModelLoaded = true
            true
        } catch (e: IOException) {
            Log.e("Server","model setup failed")
            false
        }
    }

    fun loadParameter() {
        val input = HashMap<String,Any> ()
        input["checkpoint_path"] = ckptPath
        val output = HashMap<String,Any> ()
        val bias =  FloatBuffer.allocate(10)
        output[DEBUGKEY] = bias
        interpreter?.runSignature(input,output,"restore")
        debugInfo(bias)


    }


    public fun save(checkpoint_path:String) {
        if (ModelLoaded==false) setupModel()
        if (ModelLoaded) {
            val input: MutableMap<String,Any> = HashMap()
            val output: MutableMap<String,Any> = HashMap()
            input[SAVE] = checkpoint_path
            val bias = FloatBuffer.allocate(10)
            output[DEBUGKEY] = bias
            interpreter?.runSignature(input,output,"save")
            debugInfo(bias)

        }

    }

    private fun debugInfo(bias:FloatBuffer) {
        val msg = mutableListOf<Float>()
        for (i in 0 until 10) {
            msg.add(bias.get(i))
        }
        println(msg)
    }

    public fun aggregate(paths: Array<String>, weights:FloatArray,save_path:String):String {
        if (ModelLoaded==false) setupModel()
        if (ModelLoaded) {
            val input: MutableMap<String,Any> = HashMap()
            val output: MutableMap<String,Any> = HashMap()
            input[AGGREGATE] = paths
            input[AGGREGATE_WEIGHT] = weights
            input[AGGREGATE_SAVE_PATH] = save_path
            val f = File(save_path)
            if (f.exists()) f.delete()

            val bias = FloatBuffer.allocate(10)
            output[DEBUGKEY] = bias
            interpreter?.runSignature(input,output,"aggregate")
//            debugInfo(bias)
            }
        return save_path
    }
    

    companion object {
        private val SAVE = "checkpoint_path"
        private val AGGREGATE_SAVE_PATH = "save_path"
        private val AGGREGATE = "paths"
        private val AGGREGATE_WEIGHT = "weights"
        private val AGGREGATE_RESULT = "save_path"
        private val INPUTX = "x"
        private val INPUTY = "y"
        private val LOSS = "loss"
        var batchsize = 10
    }
}