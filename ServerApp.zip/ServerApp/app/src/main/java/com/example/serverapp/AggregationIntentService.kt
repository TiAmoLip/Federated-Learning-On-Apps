package com.example.serverapp

import android.app.IntentService
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.tensorflow.lite.Interpreter
import java.io.File

//现在他已经被修改成，只有当所有的participants参与进来，才会执行这个intentService

class AggregationIntentService : IntentService("AggregationIntentService") {

    lateinit var trainer:ModelTrainingHelper
    private var save_path = "/data/data/com.example.serverapp/files/CKPT/model.ckpt"//这块只能写绝对路径
    private val clientGradients = mutableListOf<Uri>(
        Uri.parse("content://com.example.clientapp1.provider/CKPT"),
        Uri.parse("content://com.example.clientapp2.provider/CKPT")
    )
    private val dbHelper = GradientDatabase(this,"modelckpt.db",GlobalApplication.DatabaseVersion)


    @Deprecated("Deprecated in Java")
    override fun onHandleIntent(intent: Intent?) {
        Log.d("AggregationIntentService", "begin aggregating")
        if (!::trainer.isInitialized) trainer = ModelTrainingHelper(this)

        trainer.loadParameter()
        val participantNum = GlobalApplication.currentParticipants.size
        val pathArray = saveToLocal(clientGradients)
        val pt = trainer.aggregate(pathArray, floatArrayOf(0.5f, 0.5f),save_path)
        
        updateProviderDatabase(pt,Uri.parse("content://com.example.serverapp.provider/CKPT"))
        Log.d("trainIntentService", "end aggregating")
        Log.d("trainIntentService", "begin broadcasting to every client")

//有的时候出现打不开ckpt，而且路径也没错，是因为我之前随便造了一个ckpt出来，tf当然打不开了
//还有一种情况是，aggregate的output本来应该是一个什么都没有的hashmap，但是我赋了一个checkpointpath，注意output什么都不用干，什么都不用加
//        after aggregation, reminding clients

        for (i in 0 until participantNum) {
            val trainIntent = Intent("com.example.FederatedLearning.TrainSignal")
            trainIntent.setPackage(GlobalApplication.currentParticipants[i])
            sendBroadcast(trainIntent)
        }
        GlobalApplication.currentParticipants.clear()

    }
    private fun saveToLocal(uriList:MutableList<Uri>) :Array<String> {
        val path = mutableListOf<String>()
        for (i in 0 until uriList.size) {
            contentResolver.query(uriList[i],null,"id = ?", arrayOf("1"),null)?.apply {
                while (moveToNext()) {
                    val content = getBlob(getColumnIndexOrThrow("content"))
                    val clientModelFile = File("${GlobalApplication.context.filesDir.path}/clientModel/model${i}.ckpt")
                    if (!clientModelFile.exists()) clientModelFile.createNewFile()
//                    Log.d("Server Byte info ${i}",content.contentToString())
                    clientModelFile.writeBytes(content)
                    path.add(clientModelFile.path)
                }
                close()
            }
        }

        return path.toTypedArray()
    }
    private fun updateProviderDatabase(save_path:String,uri: Uri) {
        val contents = File(save_path).readBytes()
        contentResolver.update(uri, ContentValues().apply { put("content",contents) },
            "id = ?", arrayOf("1")
        )
//        Log.d("Aggregate Info",contents.contentToString())
    }


}
