package com.example.serverapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.google.gson.Gson
import java.io.File

class GradientDatabase(val context:Context, name:String, version:Int):SQLiteOpenHelper(context,name,null,version) {
    private val filePath = "data/data/com.example.serverapp/files/CKPT/model.ckpt"//这里也必须是绝对路径
    private val createCKPT = "create table CKPT (" +
            "id integer primary key autoincrement," +
            "content BLOB)"
    override fun onCreate(p0: SQLiteDatabase?) {
        val ckptFile =File(filePath)
        if (ckptFile.exists()) {
            p0?.execSQL(createCKPT)
            val bytes = ckptFile.readBytes()

            val values = ContentValues().apply {
                put("content",bytes)
            }
            Log.d("database create","yes")
            p0?.insert("CKPT",null,values)
        }
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        p0?.execSQL("DROP TABLE IF EXISTS CKPT")
        Log.d("database update from $p1 to $p2","non")
        onCreate(p0)
    }
}