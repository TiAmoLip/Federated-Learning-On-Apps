package com.example.serverapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AggregatorReceiver : BroadcastReceiver() {
    private var participantNum = 2

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("Aggregator Server","Received train signal from ${intent.getStringExtra("from")}")

        if (!(intent.`package` in GlobalApplication.currentParticipants)) {
            intent.getStringExtra("from")?.let { GlobalApplication.currentParticipants.add(it) }
        }
        if  (GlobalApplication.currentParticipants.size == participantNum) {
            val serviceIntent = Intent(context,AggregationIntentService::class.java)

            context.startService(serviceIntent)
        }

    }

    fun setParticipantNum(num: Int){
        participantNum = num

    }
}