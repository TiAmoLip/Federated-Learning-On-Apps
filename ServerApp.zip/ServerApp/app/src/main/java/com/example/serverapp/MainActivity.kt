package com.example.serverapp

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import android.widget.Button
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileWriter
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private val localGradients = listOf<String>("com.example.clientapp1")
    private val offset = 100
    private val participants = mutableListOf<String>("com.example.clientapp1","com.example.clientapp2")
    lateinit var agger:Aggregating.ServerAggregator
    lateinit var aggregatorReceiver:AggregatorReceiver

    private lateinit var requestLocalGradientIntent: Intent
    private var inputPFD: ParcelFileDescriptor? = null
    private var name2Uri: MutableMap<String, Uri> = HashMap()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(p0: ComponentName?, p1: IBinder?) {
            Log.d("Server Main Activity","bind success")

        }

        override fun onServiceDisconnected(p0: ComponentName?) {
            Log.d("Server Main Activity","unbind service")
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sendBroadcastListener()
        startServiceListener()
        registerReceiverListener()

    }



    private fun startServiceListener() {
        val startService :Button = findViewById(R.id.startService)
        startService.setOnClickListener{
            val ServiceIntent = Intent(this, Aggregating::class.java)
            startService(ServiceIntent)
            bindService(ServiceIntent,connection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun registerReceiverListener() {
        val intentFilter = IntentFilter()
        intentFilter.addAction("com.example.FederatedLearning.AggregationSignal")
        aggregatorReceiver = AggregatorReceiver()
        registerReceiver(aggregatorReceiver,intentFilter)


    }

    private fun sendBroadcastListener() {
        val sendBroadcast:Button = findViewById(R.id.sendTrainingBroadcast)
        sendBroadcast.setOnClickListener {
            for (i in 0 until participants.size) {
                val intent = Intent("com.example.FederatedLearning.TrainSignal")
                intent.setPackage(participants[i])
                sendBroadcast(intent)
                Log.d("test","send train signal to ${participants[i]}")
            }
        }
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(aggregatorReceiver)
    }

    override fun onResume() {
        super.onResume()
        val intentFilter = IntentFilter()
        intentFilter.addAction("com.example.FederatedLearning.AggregationSignal")
        registerReceiver(aggregatorReceiver,intentFilter)
    }

    override fun onDestroy() {
        super.onDestroy()
        val ServiceIntent = Intent(this, Aggregating::class.java)
        stopService(ServiceIntent)
        unbindService(connection)
        unregisterReceiver(aggregatorReceiver)

    }
}