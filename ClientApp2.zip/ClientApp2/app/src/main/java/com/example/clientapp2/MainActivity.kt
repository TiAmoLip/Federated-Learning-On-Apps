package com.example.clientapp2


import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.Log
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.core.content.contentValuesOf
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    lateinit var trainer: Training.LocalTrainer
    private var serverName = "com.example.serverapp"
    lateinit var trainSignalReceiver:SignalReceiver
    private lateinit var requestFileIntent: Intent
    private var inputPFD: ParcelFileDescriptor? = null
    private var uriFromServer = null

    private val connection = object : ServiceConnection{
        override fun onServiceConnected(p0: ComponentName?, p1: IBinder?) {

            Log.d("Client 2 Main Activity","bind success!")
        }

        override fun onServiceDisconnected(p0: ComponentName?) {

            Log.d("Client 2 Main Activity","unbind service")
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createDataset()
        registerServiceClickListener()
        registerReceiverListener()
        createGradientListener()
        updateDatabase()
    }

    private fun createDataset() {
        val filepath = "data"
        if (!File(filepath).exists()) {
            File(filepath).createNewFile()
        }
        val output = openFileOutput(filepath, Context.MODE_PRIVATE)
        val writer = BufferedWriter(OutputStreamWriter(output))
        writer.use{
            for (i in 1..1000) {
                val x = Random.nextDouble()*10
                val y = 7*x+1
                it.write("$x $y\n")
            }
        }
    }


//    private fun requestAggregatedGradient() {
//        val uri = Uri.parse("content://${serverName}.provider/Grad")
//        val params = HashMap<String,Any>()
//        val req:Button = findViewById(R.id.requestAveragedGradient)
//        req.setOnClickListener {
//            contentResolver.query(uri,null,null,null,null)?.apply {
//                while (moveToNext()) {
//                    val name = getString(getColumnIndexOrThrow("name"))
//                    val data = getString(getColumnIndexOrThrow("array"))
//                    Log.d("request from client 2",data)
//                    val type = object : TypeToken<Array<*>>() {}.type
//
//                    params[name] = Gson().fromJson(data,type)
//                }
//                val jsonStr = Gson().toJson(params)
//                val outputFile = File(this@MainActivity.filesDir.path+ File.separator+"grad","output.json")
//                BufferedWriter(FileWriter(outputFile)).use { writer ->
//                    writer.write(jsonStr)
//                }
//                close()
//            }
//
//        }
//
//    }

    private fun createGradientListener() {
        val createGradient :Button = findViewById(R.id.createGradient)
        createGradient.setOnClickListener{
            Training.createGradient(this)
        }
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(trainSignalReceiver)
    }


    override fun onDestroy() {
        super.onDestroy()
        val intent = Intent(this,Training::class.java)
        stopService(intent)
        unbindService(connection)
        unregisterReceiver(trainSignalReceiver)

    }
    private fun registerServiceClickListener() {
        val startService :Button = findViewById(R.id.startTrainingService)
        startService.setOnClickListener{
            val intent = Intent(this,Training::class.java)
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                startForegroundService(intent)
//            } else {
//                startService(intent)
//            }
            startService(intent)
            bindService(intent,connection, Context.BIND_AUTO_CREATE)
        }
    }
    private fun registerReceiverListener() {
        val intentFilter = IntentFilter()
        intentFilter.addAction("com.example.FederatedLearning.TrainSignal")
        trainSignalReceiver = SignalReceiver()
        registerReceiver(trainSignalReceiver,intentFilter)
    }

    private fun updateDatabase() {
        val dbHelper = LocalGradDatabase(this,"modelckpt.db",GlobalApplication.DatabaseVersion)
        val ckpt_path = "${this.filesDir.path}/CKPT/model.ckpt"
        val bytes = File(ckpt_path).readBytes()
        dbHelper.writableDatabase.update("CKPT", contentValuesOf().apply {
            put("content",bytes)
        },"id = ?", arrayOf("1"))
    }
}
