package com.example.clientapp2


import android.app.IntentService
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.util.Log
import android.widget.Button
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.IOException

class ModelTrainingIntentService : IntentService("ModelTrainingIntentService") {
    private val serverName = "com.example.serverapp"
    private val serverGradientUri = Uri.parse("content://${serverName}.provider/CKPT")
    private val ACTION = "com.example.FederatedLearning.AggregationSignal"
    lateinit var trainer:ModelTrainingHelper
    val ckptPath = "${GlobalApplication.context.filesDir.path}/CKPT/model.ckpt"


    override fun onHandleIntent(intent: Intent?) {

        updateStoreGradient(serverGradientUri)
        Log.d("Client 2 ModelTrainingService", "begin locally training")
        trainer = ModelTrainingHelper(this)
        trainer.loadParameter()
        trainer.loadData()
        val aggregateIntent = trainer.startTraining(ACTION,serverName)
        trainer.save(ckptPath)

        updateProviderGradient(Uri.parse("content://com.example.clientapp2.provider/CKPT"))
        sendBroadcast(aggregateIntent)
        Log.d("Client 2 ModelTrainingService", "end locally training")
    }
    private fun updateStoreGradient(uri:Uri) {
//        update parameters from server provider


        val ckptFile = File(ckptPath)
        if (!ckptFile.exists()) ckptFile.createNewFile()

        contentResolver.query(uri,null,"id = ?", arrayOf("1"),null)?.apply {

            while (moveToNext()) {
                val content = getBlob(getColumnIndexOrThrow("content"))

                ckptFile.writeBytes(content)
            }
            close()
        }
    }
    private fun updateProviderGradient(uri:Uri) {
        val ckptFile = File("${GlobalApplication.context.filesDir.path}/CKPT/model.ckpt")

        val content:ByteArray = ckptFile.readBytes()

        contentResolver.update(uri, ContentValues().apply { put("content",content) },"id = ?",
            arrayOf("1")
        )
        Log.d("Client model 2","Update the parameters of client model")
    }





}

