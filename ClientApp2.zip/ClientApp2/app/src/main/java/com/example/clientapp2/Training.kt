package com.example.clientapp2


import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.google.gson.Gson
import kotlin.concurrent.thread
import java.io.File
import java.io.FilePermission
import java.io.FileWriter

class Training : Service() {

    override fun onBind(intent: Intent) = trainBinder
    //        TODO("Return the communication channel to the service.")
    class LocalTrainer:Binder() {
        fun readData(){}

    }
    private var trainBinder = LocalTrainer()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("Client 2 Service training", "successfully started training session")
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        Log.d("Client 2 Service training", "Service stopped!")

        super.onDestroy()
    }

    override fun onCreate() {
        super.onCreate()
//        Log.d()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("myService","forehead service",NotificationManager.IMPORTANCE_DEFAULT)
            manager.createNotificationChannel(channel)

        }
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = NotificationCompat.Builder(this,"myService")
            .setContentTitle("training client 2")
            .setContentText("this app is runnning training process")
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentIntent(pi)
            .build()
        startForeground(1,notification)
    }

    companion object {
        fun createGradient(context: Context) {
//        实际上目的仅仅是为了随机生成一个json文件，因为我的想法是把梯度按照json文件保存
            val file_path:String = context.filesDir.path//   /data/user/0/com.example.clientapp1/files
//            Log.d("gradient","$file_path")
            val file = File(file_path+File.separator+"grad"+File.separator+"gradient.json")
            File(file_path+File.separator+"grad").apply {
                if (!exists()) mkdir()
            }
            if (file.exists()) return
            file.createNewFile()
            val f = FileWriter(file)
            val parameter = HashMap<String,Any>()
            parameter["conv1"] = floatArrayOf(70f,10.2f,3.03f)
            parameter["conv2"] = floatArrayOf(-12f,-15f,11.6f)
            parameter["conv3"] = listOf(floatArrayOf(20f,0.9f,-1.3f), floatArrayOf(-10.2f,112.3f,1.1f)).toTypedArray()
            f.use {
                val gson = Gson().toJson(parameter)
                it.write(gson)
            }
        }

    }
}