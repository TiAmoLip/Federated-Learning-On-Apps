package com.example.clientapp2


import android.app.Application
import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil

class GlobalApplication:Application() {
    @Suppress("StackFieldLeak")
    companion object {
        lateinit var context:Context
        var DatabaseVersion = 10

    }

    override fun onCreate() {
        super.onCreate()

        context = applicationContext

    }
}