package com.example.clientapp2

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.google.gson.Gson
import java.io.File

class LocalGradDatabase(val context:Context, name:String, version:Int):SQLiteOpenHelper(context,name,null,version) {
    private val packageName = "com.example.clientapp2"
    private val filePath = "data/data/${packageName}/files/CKPT/model.ckpt"
    private val createGrad = "create table CKPT (" +
            "id integer primary key autoincrement," +
            "content BLOB)"
    override fun onCreate(p0: SQLiteDatabase?) {
        val modelFile =File(filePath)
        if (modelFile.exists()) {
            p0?.execSQL(createGrad)
            val content = modelFile.readBytes()
            val values = ContentValues().apply {
                put("content",content)
            }
            p0?.insert("CKPT",null,values)
        }
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        p0?.execSQL("DROP TABLE IF EXISTS CKPT")
        onCreate(p0)
    }
}