package com.example.clientapp1

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.net.Uri
import android.util.Log

class LocalGradientProvider : ContentProvider() {

    private val gradientReq = 1
    private val authority = "com.example.clientapp1.provider"
    private var dbHelper:LocalGradDatabase?=null
//    object helper : LocalGradDatabase(it,"modelckpt.db",GlobalApplication.DatabaseVersion)
    private val uriMatcher by lazy {
        UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(authority,"CKPT",gradientReq)
        }
    }

    override fun onCreate() = context?.let{
        dbHelper = LocalGradDatabase(it,"modelckpt.db",GlobalApplication.DatabaseVersion)
        true
    }?:false


    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ) = dbHelper?.let {
        val db = it.readableDatabase
        when(uriMatcher.match(uri)) {
            gradientReq -> db.query("CKPT",projection,selection,selectionArgs,null,null,sortOrder)
            else -> null
        }
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        TODO("Implement this to handle requests to delete one or more rows")
    }

    override fun getType(uri: Uri): String? {
        TODO(
            "Implement this to handle requests for the MIME type of the data" +
                    "at the given URI"
        )
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        TODO("Implement this to handle requests to insert a new row.")
    }



    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<String>?
    ) = dbHelper?.let {
        val db = it.readableDatabase
        val updateRows = when(uriMatcher.match(uri)) {
            gradientReq -> db.update("CKPT",values,selection,selectionArgs)
            else -> 0
        }

        updateRows
    }?:0
}