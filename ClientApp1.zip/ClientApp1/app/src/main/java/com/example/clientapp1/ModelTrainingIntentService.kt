package com.example.clientapp1

import android.app.IntentService
import android.content.ContentProvider
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.util.Log
import android.widget.Button
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter

class ModelTrainingIntentService : IntentService("ModelTrainingIntentService") {
    private val serverName = "com.example.serverapp"
    private val serverGradientUri = Uri.parse("content://${serverName}.provider/CKPT")
    private val ACTION = "com.example.FederatedLearning.AggregationSignal"
    lateinit var trainer:ModelTrainingHelper
//    val dbHelper = LocalGradDatabase(this, "modelckpt.db", GlobalApplication.DatabaseVersion)

    override fun onHandleIntent(intent: Intent?) {

        updateStoredGradient(serverGradientUri)
        Log.d("Client 1 ModelTrainingService", "begin locally training")

        trainer = ModelTrainingHelper(this)
        trainer.loadData()
        val aggregateIntent = trainer.startTraining(ACTION,serverName)//update gradients
        trainer.save("${GlobalApplication.context.filesDir.path}/CKPT/model.ckpt")//save to model.ckpt

        updateProviderGradient(Uri.parse("content://com.example.clientapp1.provider/CKPT"))//update parameters in provider using the updated ckpt

        sendBroadcast(aggregateIntent)
        Log.d("Client 1 ModelTrainingService", "end locally training")
    }
    private fun updateStoredGradient(uri:Uri) {
//        update the content of stored model file

        val ckptPath = "${GlobalApplication.context.filesDir.path}/CKPT/model.ckpt"
        val ckptFile = File(ckptPath)
        if (!ckptFile.exists()) ckptFile.createNewFile()

        contentResolver.query(uri,null,"id = ?", arrayOf("1"),null)?.apply {

            while (moveToNext()) {
                val content:ByteArray = getBlob(getColumnIndexOrThrow("content"))
                ckptFile.writeBytes(content)
            }
            close()
        }

    }
    private fun updateProviderGradient(uri:Uri) {
        val ckptFile = File("${GlobalApplication.context.filesDir.path}/CKPT/model.ckpt")

        if (!ckptFile.exists()) ckptFile.createNewFile()
        println("checking correctness")
        trainer = ModelTrainingHelper(this) //输出了看了一下，这里还是正常的
        val content:ByteArray = ckptFile.readBytes()
        contentResolver.update(uri, ContentValues().apply { put("content",content) },"id = ?",
            arrayOf("1")
        )
    }
}
