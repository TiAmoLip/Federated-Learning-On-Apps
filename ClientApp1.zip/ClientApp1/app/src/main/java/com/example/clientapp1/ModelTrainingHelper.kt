package com.example.clientapp1

import android.content.Context
import android.content.Intent
import android.util.Log

import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.lang.RuntimeException
import java.nio.FloatBuffer


class ModelTrainingHelper(val context: Context) {
//    private var interpreter: Interpreter?=null
    private val ckptPath = "/data/data/com.example.clientapp1/files/CKPT/model.ckpt"
    private val DEBUGKEY = "dense_0/bias:0"
    private val trainingSamples: MutableList<TrainingSample> = mutableListOf()
    private var interpreter: Interpreter?=null
    var ModelLoaded = false
    data class TrainingSample(val bottleneck: FloatArray, val label: FloatArray)

    init {
        setupModel()
    }

    private fun debugInfo(bias: FloatBuffer) {
        val msg = mutableListOf<Float>()
        for (i in 0 until 10) {
            msg.add(bias.get(i))
        }
        println(msg)
    }

    private fun setupModel():Boolean {
        val options = Interpreter.Options()
        return try {
            val modelFile = FileUtil.loadMappedFile(GlobalApplication.context,"model.tflite")
            interpreter = Interpreter(modelFile, options)

            val modelPathInput = HashMap<String,Any> ()
            modelPathInput["checkpoint_path"] = ckptPath
            val output = HashMap<String,Any>()
            val bias = FloatBuffer.allocate(10)
            output[DEBUGKEY] = bias

            interpreter?.runSignature(modelPathInput,output,"restore")
            interpreter?.let {
                Log.d("Client 1 Setup", "model setup success")
//                debugInfo(bias)
            }
            ModelLoaded = true


            true
        } catch (e: IOException) {
            Log.e("Client 1 Setup","model setup failed")
            false
        }
    }
    fun loadData() {

        try {
            val input = context.openFileInput("data")
            val reader = BufferedReader(InputStreamReader(input))
            reader.use {
                reader.forEachLine {
                    val number = it.split(' ')
                    val f = floatArrayOf(number[0].toFloat())
                    val g = floatArrayOf(number[1].toFloat())
                    trainingSamples.add(TrainingSample(f,g))

                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

    }

    private fun trainingBatches(trainBatchSize: Int):Iterator<List<TrainingSample>> {
        return object : Iterator<List<TrainingSample>> {
            private var nextIndex = 0
            override fun hasNext(): Boolean {
                return nextIndex < trainingSamples.size
            }
            override fun next():List<TrainingSample> {
                val fromIndex = nextIndex
                val toIndex: Int = nextIndex + trainBatchSize
                nextIndex = toIndex
                return if (toIndex >= trainingSamples.size) {
                    trainingSamples.subList(trainingSamples.size-trainBatchSize,
                        trainingSamples.size)
                } else {
                    trainingSamples.subList(fromIndex, toIndex)
                }

            }
        }
    }
    private fun train(
        bottleneck: MutableList<FloatArray>,
        labels: MutableList<FloatArray>
    ):Float {
        val loss = FloatBuffer.allocate(1)
        if (ModelLoaded) {
            val inputs: MutableMap<String,Any> = HashMap()
            inputs [INPUTX] = bottleneck.toTypedArray()
            inputs[INPUTY] = labels.toTypedArray()
            val outputs: MutableMap<String,Any> = HashMap()

            outputs[LOSS] = loss
            interpreter?.runSignature(inputs,outputs,"train")

            return loss.get(0)
        }
        else {
            return 0f
        }
    }

    public fun startTraining(ACTION:String,SERVERNAME:String):Intent {



        val trainBatchSize = batchsize
        if (trainingSamples.size < trainBatchSize) {
            throw RuntimeException(
                String.format(
                    "To few samples to start training: need %d, got %d",
                    trainBatchSize,trainingSamples.size
                )
            )
        }
        var avgLoss: Float
        var flag: Int = 0
        while (flag<trainingSamples.size/batchsize) {
            var totalLoss = 0f
            var numBatchesProcessed = 0

            trainingBatches(trainBatchSize).forEach {
                    trainingSamples->
                val trainingBatchBottlenecks = MutableList(trainBatchSize) {
                    FloatArray(1)
                }
                val trainingBatchLabels = MutableList(trainBatchSize) {
                    FloatArray(1)
                }
                trainingSamples.forEachIndexed {
                        index, trainingSample ->
                    trainingBatchBottlenecks[index] = trainingSample.bottleneck
                    trainingBatchLabels[index] = trainingSample.label
                }
                val loss = train(trainingBatchBottlenecks,trainingBatchLabels)
                totalLoss+=loss
                numBatchesProcessed++
            }
            avgLoss = totalLoss/numBatchesProcessed
            if ((flag+1)%51==0||(flag==0)) Log.d("trainer client 1","E${flag}Average loss: $avgLoss")
            flag += 1
        }
        val aggregateIntent = Intent(ACTION)
        aggregateIntent.setPackage(SERVERNAME)
        aggregateIntent.putExtra("from",GlobalApplication.context.packageName)
        return aggregateIntent
    }


    public fun save(checkpoint_path:String) {

        if (ModelLoaded) {
            val f = File(checkpoint_path)
            if (f.exists()) f.delete()
            val input: MutableMap<String,Any> = HashMap()
            val output: MutableMap<String,Any> = HashMap()
            input[SAVE] = checkpoint_path

            val bias = FloatBuffer.allocate(10)
            output[DEBUGKEY]=bias

            interpreter?.runSignature(input,output,"save")
            debugInfo(bias)
        
        }

    }
    companion object {
        private val SAVE = "checkpoint_path"
        private val INPUTX = "x"
        private val INPUTY = "y"
        private val LABEL = "output"
        private val LOSS = "loss"
        var batchsize = 10
    }
}