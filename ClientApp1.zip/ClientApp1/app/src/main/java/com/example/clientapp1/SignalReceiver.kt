package com.example.clientapp1

import android.app.IntentService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.FileProvider
import java.io.File

class SignalReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("Client Signal Receiver 1","successfully received training signal")
//        每次收到信号，就认为我可以读取server端的参数了

        val serviceIntent = Intent(context,ModelTrainingIntentService::class.java)

        context.startService(serviceIntent)

    }


}
